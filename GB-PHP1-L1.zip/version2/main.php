<?php
$title = "Главная страница - страница обо мне";
$header1 = "Информация обо мне";
$year = 2021;

include 'index.html';