<a href="#">Главая</a>
<a href="#">О нас</a>
<br><br>